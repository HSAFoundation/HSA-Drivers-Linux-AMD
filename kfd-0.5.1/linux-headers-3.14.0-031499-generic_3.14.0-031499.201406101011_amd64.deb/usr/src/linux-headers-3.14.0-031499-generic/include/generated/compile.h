/* This file is auto generated, version 201406101011 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201406101011 SMP Tue Jun 10 10:20:54 IDT 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "TLV-GABBAY-WS"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
