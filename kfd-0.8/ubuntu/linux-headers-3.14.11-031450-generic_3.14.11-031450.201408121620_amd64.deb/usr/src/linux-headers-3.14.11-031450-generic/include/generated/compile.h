/* This file is auto generated, version 201408121620 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201408121620 SMP Tue Aug 12 16:21:50 IDT 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "tlv-gabbay-ws"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
