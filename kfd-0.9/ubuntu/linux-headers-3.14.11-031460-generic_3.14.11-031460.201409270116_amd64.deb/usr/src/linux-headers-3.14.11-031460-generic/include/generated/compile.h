/* This file is auto generated, version 201409270116 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201409270116 SMP Sat Sep 27 01:17:40 IDT 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "odedg-kaveri"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
