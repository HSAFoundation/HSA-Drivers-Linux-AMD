/* This file is auto generated, version 201505271752 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201505271752 SMP Wed May 27 17:53:58 IDT 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "tlv-gabbay-ws"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
