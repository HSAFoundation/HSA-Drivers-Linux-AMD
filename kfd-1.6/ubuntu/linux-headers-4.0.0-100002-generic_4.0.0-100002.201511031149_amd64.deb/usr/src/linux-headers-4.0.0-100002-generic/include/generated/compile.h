/* This file is auto generated, version 201511031149 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201511031149 SMP Tue Nov 3 11:49:51 EST 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "arodrig-dev"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
