/* This file is auto generated, version 201509161230 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201509161230 SMP Wed Sep 16 12:30:25 EDT 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "arodrig-dev"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
