/* This file is auto generated, version 201412060000 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201412060000 SMP Sat Dec 6 00:01:49 IST 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "odedg-kaveri"
#define LINUX_COMPILER "gcc version 4.9.1 (Ubuntu 4.9.1-16ubuntu6) "
