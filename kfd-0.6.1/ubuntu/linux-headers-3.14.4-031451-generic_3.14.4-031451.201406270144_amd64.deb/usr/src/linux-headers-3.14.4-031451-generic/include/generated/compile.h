/* This file is auto generated, version 201406270144 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201406270144 SMP Fri Jun 27 01:48:46 IDT 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "odedg-kaveri"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
